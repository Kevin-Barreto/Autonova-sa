import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [user, setUser] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (user.trim() !== '') {
      localStorage.setItem('user', user);
      navigate('/dashboard');
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-xl font-semibold mb-4">Iniciar sesión</h2>
      <form onSubmit={handleLogin} className="space-y-4">
        <input
          type="text"
          placeholder="Nombre de usuario"
          className="border p-2 w-full"
          value={user}
          onChange={(e) => setUser(e.target.value)}
        />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2">
          Ingresar
        </button>
      </form>
    </div>
  );
};

export default Login;
