# AITNOVA S.A. - Frontend

Este proyecto representa el módulo inicial del frontend para el sistema web de AITNOVA S.A., desarrollado con React, Vite y TailwindCSS.

## Instrucciones

```bash
npm install
npm run dev
```

## Desarrollado por
Kevin Barreto - GA7-220501096-AA4-EV03